package com.ocbc.wcrs.scorecard.model.node;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Generated;

import java.util.List;
import java.util.UUID;

@Data
//@Entity
//@Table(name = "t_scorecard_section")
public class ScorecardSection {

//    @Id
//    @Generated
    private UUID id;

    private String name;
    private String shortName;
    private String visibility;
    private int weightage;

//    @OneToMany
//    @JoinColumn(name = "itemId")
    private List<ScorecardItem> items;

//    @OneToMany
//    @JoinColumn(name = "scorecardVariableId")
    private List<ScorecardVariable> variables;

    private UUID formulaId;
}
