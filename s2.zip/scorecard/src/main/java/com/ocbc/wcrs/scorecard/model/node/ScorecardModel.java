package com.ocbc.wcrs.scorecard.model.node;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Generated;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

@Data
@Entity
@Table(name = "t_scorecard_model")
public class ScorecardModel {

    @Id
    @Generated
    private UUID id;
    private String name;
    private String version;
    private String type;
    private String status;

    @OneToMany
    @JoinColumn(name = "scoreGradeId")
    private List<ScoreGrade> scoreGrades;

    @OneToMany
    @JoinColumn(name = "sLTypeLocationGradeId")
    private List<SLTypeLocationGrade> slTypes;

//    @OneToMany
//    @JoinColumn(name = "moduleId")
    private Serializable model;
}
