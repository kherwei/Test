package com.ocbc.wcrs.scorecard.model.input;

import jakarta.persistence.Entity;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;
import lombok.Data;

@Data
//@Entity
//@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class ScorecardCheckbox extends MultipleOptionInput {
}
