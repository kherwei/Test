package com.ocbc.wcrs.scorecard.model.input;

import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import lombok.Data;

import java.util.List;

@Data
//@Entity
public abstract class MultipleOptionInput extends ScorecardInput {
    @OneToMany
    @JoinColumn(name="optionItemId")
    private List<OptionItem> items;
}
