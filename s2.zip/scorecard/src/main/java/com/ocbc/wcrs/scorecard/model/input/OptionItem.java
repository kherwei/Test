package com.ocbc.wcrs.scorecard.model.input;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Generated;

import java.io.Serializable;
import java.util.UUID;

@Data
//@Entity
//@Table(name = "t_option_item")
public class OptionItem {

    @Id
    @Generated
    private UUID id;

    private String label;
    private String value;
    private double score;
    private String guideText;
    private String parent;
    private String selConfirmText;
}
