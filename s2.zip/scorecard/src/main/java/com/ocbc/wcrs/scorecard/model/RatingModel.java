package com.ocbc.wcrs.scorecard.model;

import com.ocbc.wcrs.scorecard.model.node.ScorecardModel;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Generated;

import java.util.UUID;

@Data
@Entity
@Table(name = "t_rating_model")
public class RatingModel {

    @Id
    @Generated
    private UUID id;

    private String name;
    private String version;

    @OneToOne
    private ScorecardModel ogModel;
    @OneToOne
    private ScorecardModel fgModel;
}
