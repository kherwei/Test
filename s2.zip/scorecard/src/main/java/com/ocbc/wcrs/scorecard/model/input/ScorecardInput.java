package com.ocbc.wcrs.scorecard.model.input;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Generated;

import java.util.UUID;

@Data
//@Entity
//@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
//@Table(name = "t_scorecard_input")
//@DiscriminatorColumn(name = "input_type", discriminatorType = DiscriminatorType.STRING)
public abstract class ScorecardInput {

    @Id
    @Generated
    private UUID id;

    private String name;
    private String shortName;
    private int position;
    private String visibility;
}
