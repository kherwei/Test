package com.ocbc.wcrs.model.scorecard.config;

import lombok.Data;

@Data
public class ScoreGrade implements Grade {
}
