package com.ocbc.wcrs.model.scorecard.config.input;

public interface ScorecardInput {
}
