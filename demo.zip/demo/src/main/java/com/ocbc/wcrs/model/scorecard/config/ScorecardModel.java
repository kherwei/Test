package com.ocbc.wcrs.model.scorecard.config;

import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
public class ScorecardModel implements Serializable {

    String name;
    String versionName;
    String versionNumber;
    String financialTemplateName;

    List<Grade> grades = new ArrayList<>();
    List<ScorecardModule> modules = new ArrayList<>();
}
