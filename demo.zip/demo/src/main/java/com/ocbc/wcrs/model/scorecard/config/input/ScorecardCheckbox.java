package com.ocbc.wcrs.model.scorecard.config.input;

public class ScorecardCheckbox implements ScorecardInput {
}
