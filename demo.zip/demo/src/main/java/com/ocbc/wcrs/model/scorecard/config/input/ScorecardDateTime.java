package com.ocbc.wcrs.model.scorecard.config.input;

public class ScorecardDateTime implements ScorecardInput {
}
