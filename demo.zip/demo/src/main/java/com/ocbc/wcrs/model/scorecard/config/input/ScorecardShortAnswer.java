package com.ocbc.wcrs.model.scorecard.config.input;

public class ScorecardShortAnswer implements ScorecardInput {
}
