package com.ocbc.wcrs.model.scorecard.config;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class ScorecardSection {
    String name;
    List<ScorecardItem> items = new ArrayList<>();
    List<ScorecardVariable> variables = new ArrayList<>();
}
