package com.ocbc.wcrs.model.scorecard.config;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class ScorecardModule {
    String name;
    List<ScorecardSection> sections = new ArrayList<>();
    List<ScorecardVariable> variables = new ArrayList<>();
}
