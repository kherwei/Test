package com.ocbc.wcrs.model.scorecard.config.input;

public class ScorecardRadio implements ScorecardInput {
}
