package com.ocbc.wcrs.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.drools.util.FileUtils;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.ReleaseId;
import org.kie.api.builder.model.KieModuleModel;
import org.kie.api.builder.model.KieSessionModel;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieRuntimeFactory;
import org.kie.dmn.api.core.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;


@RestController
public class TestController {

    private static KieContainer buildKieModule(KieServices kieServices) throws IOException {
        final ReleaseId RELEASE_ID = KieServices.Factory.get().newReleaseId(
                "test",
                "kie-container-defaults-test",
                "1.0.0");
        KieModuleModel kieModule = kieServices.newKieModuleModel();
        kieModule.newKieBaseModel("dmn")
                .setDefault(true)
                .newKieSessionModel("session1")
                .setType(KieSessionModel.KieSessionType.STATEFUL);

        KieFileSystem kieFileSystem = kieServices.newKieFileSystem();
        kieFileSystem.generateAndWritePomXML(RELEASE_ID);
        kieFileSystem.writeKModuleXML(kieModule.toXML());

        String content = FileUtils.getFileContent("dmn-test.dmn");
        kieFileSystem.write("src/main/resources/dmn-test.dmn", kieServices.getResources().newByteArrayResource(content.getBytes()));

        final KieBuilder kieBuilder = kieServices.newKieBuilder(kieFileSystem);
        kieBuilder.buildAll();
        return kieServices.newKieContainer(RELEASE_ID);
    }

    private void execute(String a) throws IOException {
        // Method 1
        KieServices kieServices = KieServices.Factory.get();
        KieContainer kieContainer = buildKieModule(kieServices);

        // Method 2
        //KieContainer kieContainer = kieServices.getKieClasspathContainer();

        // Common
        DMNRuntime dmnRuntime = KieRuntimeFactory.of(kieContainer.getKieBase()).get(DMNRuntime.class);

        String namespace = "https://kiegroup.org/dmn/_CE55708E-BEF5-461F-9181-9D96D8F60D7D";
        String modelName = "dmn-test";

        DMNModel dmnModel = dmnRuntime.getModel(namespace, modelName);
        DMNContext dmnContext = dmnRuntime.newContext();
        dmnContext.set("input-1", Float.valueOf(a));
        DMNResult dmnResult = dmnRuntime.evaluateAll(dmnModel, dmnContext);

        for (DMNDecisionResult dr : dmnResult.getDecisionResults()) {
            System.out.println("Decision Name...: " + dr.getDecisionName());
            System.out.println("Message.........: " + dr.getMessages());
            System.out.println("Result..........: " + dr.getResult());
        }
    }

    @GetMapping("/test")
    public String test(String a) throws IOException {
        execute(a);
        return "test";
    }

    @GetMapping("/json")
    public String print() throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);


        String prettyJson = "";
        //mapper.writeValueAsString(scorecardModel);
        return prettyJson;
    }
}
