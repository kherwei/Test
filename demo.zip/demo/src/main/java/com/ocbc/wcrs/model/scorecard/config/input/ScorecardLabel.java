package com.ocbc.wcrs.model.scorecard.config.input;

public class ScorecardLabel implements ScorecardInput {
}
