package com.ocbc.wcrs.model.scorecard.config;

import com.ocbc.wcrs.model.scorecard.config.input.ScorecardInput;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class ScorecardItem {
    String name;
    List<ScorecardVariable> variables = new ArrayList<>();
    List<ScorecardInput> inputs = new ArrayList<>();
}
