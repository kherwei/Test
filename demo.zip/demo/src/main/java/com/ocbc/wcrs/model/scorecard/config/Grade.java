package com.ocbc.wcrs.model.scorecard.config;

public interface Grade {
}
