package com.ocbc.wcrs.model.scorecard.config.input;

public class ScorecardLinerScale implements ScorecardInput {
}
