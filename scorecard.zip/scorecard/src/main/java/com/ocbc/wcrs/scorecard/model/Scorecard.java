package com.ocbc.wcrs.scorecard.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Generated;

import java.util.List;
import java.util.UUID;

@Data
@Entity
@Table(name = "t_scorecard")
public class Scorecard {

    @Id
    @Generated
    private UUID id;


    private String cif;
    private String modelId;
    private int prevGrade;
    private int currGrade;

    @OneToMany
    @JoinColumn(name = "scoreId")
    private List<ScorecardScore> scores;
}
