package com.ocbc.wcrs.scorecard.model.node;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Generated;

import java.util.UUID;

@Data
@Entity
@Table(name="t_sl_location_grade")
public class SLTypeLocationGrade {

    @Id
    @Generated
    private UUID id;

    private int grade;
    private String type;
    private String location;
    private int ogGrade;
    private int fgGrade;
}
