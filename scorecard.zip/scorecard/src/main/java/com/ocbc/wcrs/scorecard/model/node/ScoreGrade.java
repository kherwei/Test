package com.ocbc.wcrs.scorecard.model.node;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Generated;

import java.util.UUID;

@Data
@Entity
@Table(name="t_score_grade")
public class ScoreGrade {

    @Id
    @Generated
    private UUID id;

    private int obligorGrade;
    private double lowerBoundScore;
    private double upperBoundScore;
    private double pd;
    private double sovereignPD;
}
