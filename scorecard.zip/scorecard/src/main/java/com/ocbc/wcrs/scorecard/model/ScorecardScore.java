package com.ocbc.wcrs.scorecard.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Generated;

import java.sql.Timestamp;
import java.util.UUID;

@Data
@Entity
@Table(name = "t_scorecard_score")
public class ScorecardScore {

    @Id
    @Generated
    private UUID id;
    private String nodeId;
    private String status;

    private double prevValue;
    private double currValue;
    private double prevScore;
    private double currScore;
    private Timestamp ts;
}
