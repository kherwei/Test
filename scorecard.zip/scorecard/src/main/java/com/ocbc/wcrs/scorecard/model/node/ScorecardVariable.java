package com.ocbc.wcrs.scorecard.model.node;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Generated;

import java.util.List;
import java.util.UUID;

@Data
//@Entity
//@Table(name = "t_scorecard_variable")
public class ScorecardVariable {

    @Id
    @Generated
    private UUID id;

    private String name;
    private String shortName;

    @OneToOne
    @MapsId
    private Formula formulas;

}
