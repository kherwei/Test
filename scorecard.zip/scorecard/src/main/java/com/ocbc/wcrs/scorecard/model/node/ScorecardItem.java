package com.ocbc.wcrs.scorecard.model.node;

import com.ocbc.wcrs.scorecard.model.input.ScorecardInput;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Generated;

import java.util.List;
import java.util.UUID;

@Data
//@Entity
//@Table(name = "t_scorecard_item")
public class ScorecardItem {

    @Id
    @Generated
    private UUID id;

    private String name;
    private String shortName;
    private String questionText;
    private String guideText;
    private String visibility;
    private int weightage;

    @OneToMany
    @JoinColumn(name="scorecardVariableId")
    private List<ScorecardVariable> variables;

    @OneToMany
    @JoinColumn(name="scorecardInputId")
    private List<ScorecardInput> inputs;

    @OneToOne
    @MapsId
    private Formula formulas;

}
