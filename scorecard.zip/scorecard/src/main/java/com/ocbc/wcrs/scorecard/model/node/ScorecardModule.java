package com.ocbc.wcrs.scorecard.model.node;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Generated;

import java.util.List;
import java.util.UUID;

@Data
//@Entity
//@Table(name = "t_scorecard_module")
public class ScorecardModule {

    @Id
    @Generated
    private UUID id;

    private String name;
    private String shortName;
    private int position;

    @OneToMany
    @JoinColumn(name="sectionId")
    private List<ScorecardSection> sections;

    @OneToMany
    @JoinColumn(name="variableId")
    private List<ScorecardVariable> variables;

    @OneToOne
    @MapsId
    private Formula formulas;

}
